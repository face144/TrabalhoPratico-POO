#ifndef TRABALHOPRATICO_POO_INTERFACE_H
#define TRABALHOPRATICO_POO_INTERFACE_H

#include "engine.h"

class Interface {

    Engine CivilizationPunk2078;

public:

};


#endif //TRABALHOPRATICO_POO_INTERFACE_H
