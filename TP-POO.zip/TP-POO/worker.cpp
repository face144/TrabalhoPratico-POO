#include "worker.h"

Worker::Worker(float quit_prob, int quit_prob_start_day, int n, int d, string type) {
}

#pragma region Sets

void Worker::setXCoord(int x) {
	this->x + x;
}

void Worker::setYCoord(int y) {
	this->y + y;
}

void Worker::setType(string type) {
	this->type + type;
}

void Worker::setCost(int cost) {
	this->cost = cost;
}

void Worker::setQuitProb(int quit_prob) {
	this->quit_prob = quit_prob;
}

void Worker::setQuitProbStartDay(int quit_prob_start_day) {
	this->quit_prob_start_day = quit_prob_start_day;
}

#pragma endregion


#pragma region Gets

int Worker::getXCoord() {
	return x;
}

int Worker::getYCoord() {
	return y;
}

string Worker::getType() {
	return type;
}

int Worker::getCost() {
	return this->cost;
}

int Worker::getQuitProb() {
	return this->quit_prob;
}

int Worker::getQuitProbStartDay() {
	return this->quit_prob_start_day;
}

#pragma endregion