#include "engine.h"



void Engine::setUsername(string username) {
    this->username = username;
}

string Engine::getUsername() {
    return username;
}

void Engine::setMapRows(int map_rows) {
    this->map_rows = map_rows;
}

void Engine::setMapCols(int map_cols) {
    this->map_cols = map_cols;
}

int Engine::getMapRows() {
    return map_rows;
}

int Engine::getMapCols() {
    return map_cols;
}

void Engine::setDay(int day) {
    this->day = day;
}

int Engine::getDay() const {
    return day;
}

void Engine::setMapSize() {
    map_size = map_rows * map_cols;
}

int Engine::getMapSize() {
    return map_size;
}

#pragma region CMD

bool Engine::cmdCons(string type, int x, int y) {
    if (type == "minaf") {
        apiCons(type, x, y);
        guiCons(type, x, y);
    }
}

bool Engine::cmdLiga(int x, int y) {
    int id;
    string temp;
    id = (x * y) - 1;
    if (x > 8 or y > 16 or x <3 or y < 3)
        return false;
    if (island[id].getBuilding() == "ndef")
        return false;
    else
        temp = island[id].getBuilding();

    if(temp == "minaf")
        for(int i=0; i != oIronMine.size()-1 ; i++ )
            if (oIronMine[i].getXCoord() == x && oIronMine[i].getYCoord() == y)
                if (oIronMine[i].getIsOnline())
                    return false;
                else
                    apiLiga(oIronMine[i]);

    return true;
}

bool Engine::cmdDes(int x, int y) {
    int id;
    string temp;
    id = (x * y) - 1;
    if (x > 8 or y > 16 or x < 3 or y < 3)
    return false;


    if (island[id].getBuilding() == "ndef")
        return false;
    else
        temp = island[id].getBuilding();


    if(temp == "minaf")
        for(int i=0; i != oIronMine.size()-1 ; i++ )
            if (oIronMine[i].getXCoord() == x && oIronMine[i].getYCoord() == y)
                if (!oIronMine[i].getIsOnline())
                    return false;
                else
                    apiDes(oIronMine[i]);

    return true;
}
bool Engine::cmdMove(int id, int x, int y) {
    int ind;
    string temp;
    ind = (x * y) - 1;
    if (x > map_cols and y > map_rows or x <1 and y < 1)
        return false;

    for(int i=0; i != oMiner.size()-1 ; i++ )
        if (oIronMine[i].getXCoord() == x && oIronMine[i].getYCoord() == y)
            if (!oIronMine[i].getIsOnline())
                return false;
            else
                apiDes(oIronMine[i]);

}

bool Engine::cmdVende(int x, int y) {

}
bool Engine::cmdCont(string type) {
    if(type != "oper" && type != "len" && type != "miner")
        return false;

    guiCont(type);
    apiCont(type);
}

#pragma endregion


#pragma region GUI

bool Engine::guiCons(string type, int x, int y) {
    int id;
    id = (x * y) - 1;
    if (x > 8 or y > 16 or x < 3 or y < 3){
        return false;
    }
    island[id].setBuildingType(type);
    return true;
}

bool Engine::guiCont(string type) {
    //if(type == "miner")



}

bool Engine::guiList(int x, int y) {
    if(x != NULL and y != NULL){
        cout << island[x*y-1].getType();
        cout << island[x*y-1].getBuilding();
        cout << island[x*y-1].getWorker();
        cout << island[x*y-1].getNrWorker();

    }else
        island[x*y-1].printCell();
}
#pragma endregion


#pragma region API

void Engine::apiCons(Building oBuilding, int x, int y) {
    if (oBuilding.getType() == "minaf") {
        oBuilding.setCoords(x, y);
        oIronMine.push_back(oBuilding);
    }
}

void Engine::apiLiga(Building temp) {
    temp.setIsOnline(true);

}

void Engine::apiDes(Building temp) {
    temp.setIsOnline(false);
}

bool Engine::apiCont(string type) {
    if(type == "miner") {
        Worker oWorker(0.10,2,oMiner.size(),getDay(), type);
        oMiner.push_back(oWorker);
    }
}

bool Engine::apiList(int x, int y) {

}

#pragma endregion

vector <string> Engine::inputHandler(string input) {

    vector <string> command;
    istringstream iss;
    string temp;

    if (iss.str().empty()) {
        command.emplace_back("");
        return command ;
    }

    while (getline(iss, temp, ' '))
        command.push_back(temp);

    int i = 0;
    if (command [i++] == "cons") {
        if (command[i++] == "minaf");

    } else if (command[i++] == "liga") {

    } else if (command[i++] == "des") {

    } else if (command[i++] == "move") {
        if(command[i++] == "");

    } else if (command[i++] == "vende") {
        if(command[i++] == "ferro" or command[i++] == "aco" or command[i++] == "carvao" or command[i++] == "mad" or command[i++] == "viga" or command[i++] == "eletr")
            if (i++);

    }else if (command[i++] == "cont") {
        if(command[i++] == "oper" or command[i++] == "len" or command[i++] == "miner");

    }else if (command[i++] == "list") {

    }else if(command[i++] == "vende"){

    }else if(command[i++] == "next"){

    }else if(command[i++] == "save"){

    }else if(command[i++] == "load"){

    }else if(command[i++] == "apaga"){

    }else if(command[i++] == "config"){

    }else if(command[i++] == "debcash"){

    }else if(command[i++] == "debed"){
        if(command[i++] == "minaf" or command[i++] == "minac" or command[i++] == "central" or command[i++] == "bat" or command[i++] == "fund" or command[i++] == "edx");

    }else if(command[i++] == "debkill"){

    }

    else {
        cout << "Comando invalido!" << endl;
    }

    return command;
}