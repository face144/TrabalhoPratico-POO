#ifndef worker_h
#define worker_h

#include <iostream>

using namespace std;

class Worker {
private:
	int x, y, cost, quit_prob, quit_prob_start_day;
	string type;

public:
    Worker(float quit_prob, int quit_prob_start_day, int n, int d, string type);

#pragma region Sets

	void setXCoord(int x);

	void setYCoord(int y);

	void setType(string type);

	void setCost(int cost);

	void setQuitProb(int quit_prob);

	void setQuitProbStartDay(int quit_prob_start_day);

#pragma endregion

#pragma region Gets

	int getXCoord();

	int getYCoord();

	string getType();

	int getCost();

	int getQuitProb();

	int getQuitProbStartDay();

#pragma endregion

};

#endif //worker_h