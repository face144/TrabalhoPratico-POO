#include "cell.h"

Cell::Cell(int map_cols, int map_rows) {
    setBuildingType("undef");
    setWorker("(no one)");
    setNrWorker(0);

    for (int i = 0; i < map_rows; ++i) {
        for (int j = 0; j < map_cols; ++j) {

            srand(time(0));
            int temp = rand() % 5 + 1;
            switch (temp) {
                case 1:
                    type = type_str_code_mnt;
                    break;
                case 2:
                    type = type_str_code_dsr;
                    break;
                case 3:
                    type = type_str_code_pas;
                    break;
                case 4:
                    type = type_str_code_flr;
                    break;
                case 5:
                    type = type_str_code_pnt;
                    break;
            }

            island.emplace_back(type);
        }
    }
}

string Cell::printCell() {
    ostringstream oss;

    for (int i = 0; i < map_cols; ++i) {

        for (int h = 0; h < map_rows; ++h) {
            oss << "________________ ";
        }

        oss << endl;
        for (int h = 0; h < map_rows; ++h) {
            oss << "|" << island[i * h] << "| ";
        }

        oss << endl;
        for (int h = 0; h < map_rows; ++h) {
            oss << "|" << building_type << "| ";
        }

        oss << endl;
        for (int h = 0; h < map_rows; ++h) {
            oss << "|" << worker_type << "| ";
        }

        oss << endl;
        for (int h = 0; h < map_rows; ++h) {
            oss << "|" << nr_worker << "             | ";
        }

        oss << endl;
        for (int h = 0; h < map_rows; ++h) {
            oss << "________________ ";
        }
        oss << endl;
    }

    return oss.str();
}

#pragma region Sets

void Cell::setMapRows(int map_rows) {
    this->map_rows;
}

void Cell::setMapCols(int map_cols) {
    this->map_cols = map_cols;
}

void Cell::setType(string type) {
    this->type = type;
}

void Cell::setBuildingType(string building_type) {
    this->building_type = building_type;
}

void Cell::setWorker(string worker_type) {
    this->worker_type = worker_type;
}

void Cell::setNrWorker(int nr_worker) {
    this->nr_worker = nr_worker;
}

#pragma endregion


#pragma region Gets

int Cell::getMapRows() {
    return map_rows;
}

int Cell::getMapCols() {
    return map_cols;
}

string Cell::getType() {
    return this->type;
}
string Cell::getBuilding(){
    return this->building_type;
}
string Cell::getWorker(){
    return this->worker_type;
}
int Cell::getNrWorker(){
    return this->nr_worker;
}

#pragma endregion

