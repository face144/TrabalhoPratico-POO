#include <filereader.h>

string Filereader::getFileCmds() {
	ifstream ifs;
	ifs.open(filename);

	istringstream iss;
    string line;

    for (int i = 0; getline(ifs, line); i++) {
        iss >> line;
    }

	ifs.close();

	return iss.str();
}

void Filereader::setFilename(string filename) {
	this->filename = filename;
}