#ifndef filereader_h
#define filereader_h

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;

class Filereader {
private:
	string *commands[100];
	string filename;

public:
    string getFileCmds();

    void setFilename(string filename);

};

#endif //filereader_H
