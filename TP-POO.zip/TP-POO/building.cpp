#include "building.h"

Building::Building (string type) {

	if (type == "minaf") {
			setType(type);
			setLevel(1);
			setMaxLevel(minaf_max_level);
			setDestroyProb(minaf_destroy_prob);
			setOutput(minaf_output);
			setOutputType(minaf_output_type);
			setNeedsWorker(minaf_needs_worker);
			setWorkerType(minaf_worker_type);
			setStorageType(minaf_output_type);

    } // else if () {}
}

Building::~Building() {

}

#pragma region Gets

int Building::getXCoord() {
	return x;
}

int Building::getYCoord() {
	return y;
}

string Building::getType() {
	return this->type;
}

int Building::getBuildCostWoodBeam() {
    return this->minaf_build_cost_wood_beam;
}

int Building::getBuildCostAlt() {
	return this->minaf_build_cost_alt;
}

int Building::getLevel() {
	return this->level;
}

int Building::getMaxLevel() {
	return this->max_level;
}

float Building::getDestroyProb() {
	return this->destroy_prob;
}

int Building::getOutput() {
	return this->output;
}

string Building::getOutputType() {
	return this->output_type;
}

int Building::getUpgrdPerkOutput() {
	return this->upgrd_perk_output;
}

int Building::getUpgrdPerkStorage() {
	return this->upgrd_perk_storage;
}

int Building::getUpgrdCostMoney() {
	return this->upgrd_cost_money;
}

int Building::getUpgrdCostWoodBeam() {
	return this->upgrd_cost_wood_beam;
}

bool Building::getNeedsWorker() {
	return this->needs_worker;
}

string Building::getWorkerType() {
	return this->worker_type;
}

int Building::getStorage() {
	return this->storage;
}

string Building::getStorageType() {
	return this->storage_type;
}

bool Building::getIsOnline() {
    return is_online;
}

#pragma endregion


#pragma region Sets

void Building::setCoords(int x, int y) {
	this->x = x;
	this->y = y;
}

void Building::setType(string type) {
	this->type = type;
}

void Building::setLevel(int level) {
	this->level = level;
}

void Building::setMaxLevel(int max_level) {
	this->max_level = max_level;
}

/*void Building::setBuildCostAlt(int build_cost_alt, string build_cost_alt_type) {
	this->cost_alt = cost_alt;
	this->cost_alt_name = cost_alt_name;
}

void Building::getBuildCostAltType(string build_cost_alt_type) {
	this->build_cost_alt_type = build_cost_alt_type;
}*/

void Building::setDestroyProb(float destroy_prob) {
	this->destroy_prob = destroy_prob;
}

void Building::setOutput(int output) {
	this->output = output;
}

void Building::setOutputType(string output_type) {
	this->output_type = output_type;
}

void Building::setUpgrdPerkOutput(int upgrd_perk_output) {
	this->upgrd_perk_output = upgrd_perk_output;
}

void Building::setUpgrdPerkStorage(int upgrd_perk_storage) {
	this->upgrd_perk_storage = upgrd_perk_storage;
}

void Building::setUpgrdCostMoney(int upgrd_cost_money) {
	this->upgrd_cost_money = upgrd_cost_money;
}

void Building::setUpgrdCostWoodBeam(int upgrd_cost_wood_beam) {
	this->upgrd_cost_wood_beam = upgrd_cost_wood_beam;
}

void Building::setNeedsWorker(bool needs_worker) {
	this->needs_worker = needs_worker;
}

void Building::setWorkerType(string worker_type) {
	this->worker_type = worker_type;
}

void Building::setStorage(int storage) {
	this->storage = storage;
}

void Building::setStorageType(string storage_type) {
	this->storage_type = storage_type;
}

void Building::setIsOnline(bool is_online){
    this->is_online = is_online;
}
#pragma endregion
