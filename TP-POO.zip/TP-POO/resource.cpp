#include "resource.h"

Resource::Resource() {
}

#pragma region Sets

void Resource::setType(string type) {
	this->type = type;
}

void Resource::setSellMoney(int sell_money) {
	this->sell_money = sell_money;
}

#pragma endregion


#pragma region Gets

string Resource::getType() {
	return this->type;
}

int Resource::getSellMoney() {
	return this->sell_money;
}

#pragma endregion