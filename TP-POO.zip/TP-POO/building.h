#ifndef building_h
#define building_h

#include <iostream>
#include "resource.h"


using namespace std;

class Building {
private:

#pragma region minaf

    const int minaf_max_level = 5;

    const float minaf_destroy_prob = .15;

    const int minaf_output = 2;
    const string minaf_output_type = "iron";

    const int minaf_build_cost_wood_beam = 10;
    const int minaf_build_cost_alt = 100;

    const int minaf_upgrd_perk_output = 1;
    const int minaf_upgrd_perk_storage = 10;

    const bool minaf_needs_worker = true;
    const string minaf_worker_type = "miner";

    const int minaf_storage = 100;

#pragma endregion

    int x, y;

    string type;
    int level, max_level;
    float destroy_prob;

    int output;
    string output_type;

    int upgrd_perk_output;
    int upgrd_perk_storage;

    int upgrd_cost_money;
    int upgrd_cost_wood_beam;

    bool needs_worker;
    string worker_type;

    int storage;
    string storage_type;

    bool is_online;

public:
    Building(string type);

    ~Building();

#pragma region Gets

    int getXCoord();

    int getYCoord();

    string getType();

    int getBuildCostWoodBeam();

    int getBuildCostMoney();

    int getLevel();

    int getMaxLevel();

    int getBuildCostAlt();

    string getBuildCostAltType();

    float getDestroyProb();

    int getOutput();

    string getOutputType();

    int getUpgrdPerkOutput();

    string getUpgrdPerkOutputType();

    int getUpgrdPerkStorage();

    int getUpgrdCostMoney();

    int getUpgrdCostWoodBeam();

    bool getNeedsWorker();

    string getWorkerType();

    int getStorage();

    string getStorageType();

    bool getIsOnline();

#pragma endregion


#pragma region Sets

    void setCoords(int x, int y);

    void setType(string type);

    void setLevel(int level);

    void setMaxLevel(int max_level);

    void setBuildCostWoodBeam(int build_cost_wood_beam);

    void setBuildCostMoney(int build_cost_money);

    void setBuildCostAlt(int build_cost_alt);

    void setBuildCostAltType(string build_cost_alt_type);

    void setDestroyProb(float destroy_prob);

    void setOutput(int output);

    void setOutputType(string output_type);

    void setUpgrdPerkOutput(int upgrd_perk_output);

    void setUpgrdPerkStorage(int upgrd_perk_storage);

    void setUpgrdCostMoney(int upgrd_cost_money);

    void setUpgrdCostWoodBeam(int upgrd_cost_wood_beam);

    void setNeedsWorker(bool needs_worker);

    void setWorkerType(string worker_type);

    void setStorage(int storage);

    void setStorageType(string storage_type);

    void setIsOnline(bool is_online);
#pragma endregion

};

#endif //building_h

