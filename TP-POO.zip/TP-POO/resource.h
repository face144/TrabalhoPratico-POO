#ifndef resource_h
#define resource_h

#include <iostream>

using namespace std;

class Resource {
private:
	string type;
	int sell_money;

public:
	Resource();

#pragma region Sets

	void setType(string type);

	void setSellMoney(int sell_money);

#pragma endregion


#pragma region Gets

	string getType();

	int getSellMoney();

#pragma endregion

};

#endif //resource_h