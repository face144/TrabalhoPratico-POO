#ifndef engine_h
#define engine_h

#include <iostream>
#include <string>
#include <vector>

#include "building.h"
#include "filereader.h"
#include "resource.h"
#include "worker.h"
#include "cell.h"
#define MAX 50

using namespace std;

class Engine {
private:
#pragma region Environment vars

	string username;
	int player_resource_money;
	int player_resource_wood;
	int player_resource_wood_beam;
    int day = 0;

	int map_rows = 0;
	int map_cols = 0;
    int map_size;

#pragma endregion


#pragma region GUI & API

    bool guiCons(string type, int x, int y);

    void apiCons(Building oBuilding, int x, int y);

    void apiLiga (Building type);

    void apiDes(Building temp);

    bool guiMove(int id, int x, int y);

    bool apiMove(int id, int x, int y);

    bool guiVende(string type, int quant);

    bool apiVende(string type, int quant);

    bool guiCont(string type);

    bool apiCont(string type);

    bool guiList(int x, int y);

    bool apiList(int x, int y);

    bool guiVende(int x, int y);

    bool apiVende(int x, int y);

    bool guiNext();

    bool apiNext();

    bool guiSave(string nome);

    bool apiSave(string nome);

    bool guiLoad(string nome);

    bool apiLoad(string nome);

    bool guiConfig();

    bool apiConfig();

    bool guiDebcash(int valor);

    bool apiDebcash(int valor);

    bool guiDebed(string type);

    bool apiDebed(string type);

    bool guiDebkill(int id);

    bool apiDebkill(int id);

#pragma endregion

public:
    Cell island[MAX];
    vector <Building> oIronMine;
    vector <Worker> oMiner;

    Engine(Cell island);

    void setUsername(string username);

    string getUsername();

    void setMapRows(int map_rows);

    int getMapRows();

    void setMapCols(int map_cols);

    int getMapCols();

    void setDay(int day);

    int getDay() const;

    int getMapSize();

    void setMapSize();

#pragma region CMD

	bool cmdCons(string type, int x, int y);

    bool cmdLiga (int x, int y);

    bool cmdDes (int x, int y);

    bool cmdMove(int id, int x, int y);

    bool cmdVende(string type, int quant);

    bool cmdCont(string type);

    bool cmdList(int x, int y);

    bool cmdVende(int x, int y);

    bool cmdNext();

    bool cmdSave(string nome);

    bool cmdLoad(string nome);

    bool cmdConfig();

    bool cmdDebcash(int valor);

    bool cmdDebed(string type);

    bool cmdDebkill(int id);

#pragma endregion

    vector <string> inputHandler(string input);

};

#endif // !engine_h
