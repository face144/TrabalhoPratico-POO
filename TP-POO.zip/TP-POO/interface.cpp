#include "interface.h"

Interface::Interface() {

}

void Interface::Create() {
    cout << "Nome de usuario: ";
    string username;
    cin >> username;

    system("cls");

    int map_rows = 0, map_cols = 0;

    cout << "Tamanho do mapa:" << endl
         << "(O mapa pode ser no minimo de 3x3, linhas e colunas respetivamente, e no maximo 8x16)" << endl << endl;

    while (map_rows < 3 || map_rows > 8) {
        cout << "Insira o numero de linhas desejado: ";
        cin >> map_rows;

        if (map_rows < 3 || map_rows > 8)
            cout << endl <<"Valor Invalido" << endl;
    }

    while (map_cols < 3 || map_cols > 16) {
        cout << "Insira o numero de colunas desejado: ";
        cin >> map_cols;

        if (map_cols < 3 || map_cols > 16)
            cout << endl << "Valor Invalido" << endl;
    }

    CivilizationPunk2078.setUsername(username);
    CivilizationPunk2078.setMapCols(map_cols);
    CivilizationPunk2078.setMapRows(map_rows);
    CivilizationPunk2078.island.setMapCols(map_cols);
    CivilizationPunk2078.island.setMapRows(map_rows);
    CivilizationPunk2078.setMapSize();

    system("cls");
    cout << "|||||||||||||||||||||||||||||||||||||||" << endl;
    cout << "|||||||| CivilizationPunk 2078 ||||||||" << endl;
    cout << "|||||||||||||||||||||||||||||||||||||||" << endl;
    cout << endl << endl << endl;


    cout << "Escreva 'ajuda' para a lista de comandos." << endl;
}

void Interface::StepEvent() {
    while (1) {
        CivilizationPunk2078.setDay(CivilizationPunk2078.getDay() + 1);
        cout << CivilizationPunk2078.island.printCell(); //Esta merda e deficiente

        cout << CivilizationPunk2078.getUsername() << ": ";
        string input;
        getline(cin, input);

        CivilizationPunk2078.inputHandler(input);

    }
}