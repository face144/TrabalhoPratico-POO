#ifndef TP_ISLAND_H
#define TP_ISLAND_H

#include <iostream>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <ctime>

using namespace std;


class Cell{
    int map_cols, map_rows;
    string type;
    string building_type;
    string worker_type;
    int nr_worker;

    vector <string> island;

#pragma region Constants
    const string type_str_code_mnt = "mnt";
    const int type_num_code_mnt = 1;
    const string type_str_code_dsr = "dsr";
    const int type_num_code_dsr = 2;
    const string type_str_code_pas = "pas";
    const int type_num_code_pas = 3;
    const string type_str_code_flr = "flr";
    const int type_num_code_flr = 4;
    const string type_str_code_pnt = "pnt";
    const int type_num_code_pnt = 5;
#pragma endregion

public:
    Cell(int map_cols, int map_rows);

    string printCell();

#pragma region Gets

    int getMapRows();

    int getMapCols();

    string getType();

    string getBuilding();

    string getWorker();

    int getNrWorker();

#pragma endregion

#pragma region Sets

    void setMapRows(int map_rows);

    void setMapCols(int map_cols);

    void setType(string type);

    void setBuildingType(string building_type);

    void setWorker(string worker_type);

    void setNrWorker(int nr_worker);

#pragma endregion

};


#endif //TP_ISLAND_H
